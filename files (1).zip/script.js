const API_BASE = "/api/students";

const form = document.getElementById("studentForm");
const idField = document.getElementById("studentId");
const nameField = document.getElementById("name");
const rollField = document.getElementById("roll_no");
const emailField = document.getElementById("email");
const courseField = document.getElementById("course");
const yearField = document.getElementById("year");
const marksField = document.getElementById("marks");

const formTitle = document.getElementById("formTitle");
const cardIndex = document.getElementById("cardIndex");
const formErrors = document.getElementById("formErrors");
const submitBtn = document.getElementById("submitBtn");
const cancelBtn = document.getElementById("cancelBtn");

const tableBody = document.getElementById("tableBody");
const emptyState = document.getElementById("emptyState");
const recordCount = document.getElementById("recordCount");
const searchInput = document.getElementById("searchInput");
const toast = document.getElementById("toast");

let editingId = null;
let searchTimer = null;

// ---------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------

function renderRows(students) {
  tableBody.innerHTML = "";

  if (students.length === 0) {
    emptyState.hidden = false;
  } else {
    emptyState.hidden = true;
  }

  for (const s of students) {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="roll">${escapeHtml(s.roll_no)}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.course)}</td>
      <td>${s.year}</td>
      <td class="marks">${Number(s.marks).toFixed(1)}</td>
      <td>
        <div class="row-actions">
          <button type="button" data-action="edit" data-id="${s.id}">Edit</button>
          <button type="button" data-action="delete" data-id="${s.id}" class="danger">Delete</button>
        </div>
      </td>
    `;
    tableBody.appendChild(tr);
  }

  recordCount.textContent = `${students.length} record${students.length === 1 ? "" : "s"}`;
}

function escapeHtml(value) {
  const div = document.createElement("div");
  div.textContent = String(value ?? "");
  return div.innerHTML;
}

function showToast(message, isError = false) {
  toast.textContent = message;
  toast.hidden = false;
  toast.className = "toast" + (isError ? " toast--error" : "");
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => { toast.hidden = true; }, 2600);
}

function showFormErrors(messages) {
  if (!messages || messages.length === 0) {
    formErrors.hidden = true;
    formErrors.textContent = "";
    return;
  }
  formErrors.hidden = false;
  formErrors.textContent = messages.join(" ");
}

// ---------------------------------------------------------------------
// API calls
// ---------------------------------------------------------------------

async function fetchStudents(query = "") {
  const url = query ? `${API_BASE}?q=${encodeURIComponent(query)}` : API_BASE;
  const res = await fetch(url);
  const data = await res.json();
  renderRows(data);
}

async function loadStudents() {
  try {
    await fetchStudents(searchInput.value.trim());
  } catch (err) {
    showToast("Could not reach the server.", true);
  }
}

function collectFormData() {
  return {
    name: nameField.value.trim(),
    roll_no: rollField.value.trim(),
    email: emailField.value.trim(),
    course: courseField.value.trim(),
    year: yearField.value,
    marks: marksField.value,
  };
}

async function submitForm(evt) {
  evt.preventDefault();
  showFormErrors(null);

  const payload = collectFormData();
  const method = editingId ? "PUT" : "POST";
  const url = editingId ? `${API_BASE}/${editingId}` : API_BASE;

  submitBtn.disabled = true;
  try {
    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      showFormErrors(data.details || [data.error || "Something went wrong."]);
      return;
    }

    showToast(editingId ? "Record updated." : "Added to register.");
    resetForm();
    await loadStudents();
  } catch (err) {
    showToast("Could not reach the server.", true);
  } finally {
    submitBtn.disabled = false;
  }
}

async function deleteStudent(id) {
  if (!confirm("Remove this student from the register? This cannot be undone.")) return;
  try {
    const res = await fetch(`${API_BASE}/${id}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || "Could not delete record.", true);
      return;
    }
    showToast("Record removed.");
    if (editingId === String(id)) resetForm();
    await loadStudents();
  } catch (err) {
    showToast("Could not reach the server.", true);
  }
}

async function editStudent(id) {
  try {
    const res = await fetch(`${API_BASE}/${id}`);
    const data = await res.json();
    if (!res.ok) {
      showToast(data.error || "Could not load record.", true);
      return;
    }
    editingId = String(id);
    idField.value = data.id;
    nameField.value = data.name;
    rollField.value = data.roll_no;
    emailField.value = data.email;
    courseField.value = data.course;
    yearField.value = data.year;
    marksField.value = data.marks;

    formTitle.textContent = "Edit entry";
    cardIndex.textContent = `#${data.id}`;
    submitBtn.textContent = "Save changes";
    cancelBtn.hidden = false;
    showFormErrors(null);
    nameField.focus();
  } catch (err) {
    showToast("Could not reach the server.", true);
  }
}

function resetForm() {
  editingId = null;
  form.reset();
  idField.value = "";
  formTitle.textContent = "New entry";
  cardIndex.textContent = "—";
  submitBtn.textContent = "Add to register";
  cancelBtn.hidden = true;
  showFormErrors(null);
}

// ---------------------------------------------------------------------
// Events
// ---------------------------------------------------------------------

form.addEventListener("submit", submitForm);
cancelBtn.addEventListener("click", resetForm);

tableBody.addEventListener("click", (evt) => {
  const btn = evt.target.closest("button[data-action]");
  if (!btn) return;
  const id = btn.dataset.id;
  if (btn.dataset.action === "edit") editStudent(id);
  if (btn.dataset.action === "delete") deleteStudent(id);
});

searchInput.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadStudents, 250);
});

loadStudents();
